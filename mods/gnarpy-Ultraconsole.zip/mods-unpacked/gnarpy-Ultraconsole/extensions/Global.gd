extends "res://Global.gd"

func _ready() -> void:
    super()
    LimboConsole.enabled = true
